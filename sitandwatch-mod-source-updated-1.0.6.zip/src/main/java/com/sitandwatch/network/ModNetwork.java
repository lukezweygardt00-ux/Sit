package com.sitandwatch.network;

import com.sitandwatch.SitAndWatch;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.network.simple.SimpleChannel;

public class ModNetwork {
    private static final String PROTOCOL = "1";
    public static SimpleChannel CHANNEL;

    public static void register() {
        CHANNEL = NetworkRegistry.newSimpleChannel(new ResourceLocation(SitAndWatch.MOD_ID, "main"),
                () -> PROTOCOL, PROTOCOL::equals, PROTOCOL::equals);
        int id = 0;
        CHANNEL.registerMessage(id++, CameraLockPacket.class, CameraLockPacket::encode, CameraLockPacket::decode, CameraLockPacket::handle);
        CHANNEL.registerMessage(id++, SubtitlePacket.class, SubtitlePacket::encode, SubtitlePacket::decode, SubtitlePacket::handle);
        CHANNEL.registerMessage(id++, NudgePacket.class, NudgePacket::encode, NudgePacket::decode, NudgePacket::handle);
        CHANNEL.registerMessage(id++, EffectPacket.class, EffectPacket::encode, EffectPacket::decode, EffectPacket::handle);
        CHANNEL.registerMessage(id++, GuidePacket.class, GuidePacket::encode, GuidePacket::decode, GuidePacket::handle);
    }

    public static void sendTo(ServerPlayer player, Object msg) {
        if (CHANNEL != null) CHANNEL.send(PacketDistributor.PLAYER.with(() -> player), msg);
    }
}
