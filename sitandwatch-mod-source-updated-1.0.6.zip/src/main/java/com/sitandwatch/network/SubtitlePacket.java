package com.sitandwatch.network;

import com.sitandwatch.client.ClientState;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Shows a big story subtitle (translation key) for some ticks; optionally with a distorted look. */
public class SubtitlePacket {
    public final String key;
    public final int ticks;
    public final boolean distorted;

    public SubtitlePacket(String key, int ticks, boolean distorted) {
        this.key = key; this.ticks = ticks; this.distorted = distorted;
    }

    public static void encode(SubtitlePacket m, FriendlyByteBuf b) {
        b.writeUtf(m.key); b.writeInt(m.ticks); b.writeBoolean(m.distorted);
    }

    public static SubtitlePacket decode(FriendlyByteBuf b) {
        return new SubtitlePacket(b.readUtf(), b.readInt(), b.readBoolean());
    }

    public static void handle(SubtitlePacket m, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ClientState.showSubtitle(m.key, m.ticks, m.distorted)));
        ctx.get().setPacketHandled(true);
    }
}
