package com.sitandwatch.entity;

import com.sitandwatch.registry.ModSounds;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.level.Level;

import javax.annotation.Nullable;

/** Smug Bro: permanent smirk, deep garbled villager voice, gesturing arms. */
public class SmugBroEntity extends StoryVillager {
    public SmugBroEntity(EntityType<? extends PathfinderMob> type, Level level) {
        super(type, level);
        this.setInvulnerable(true);
    }

    @Nullable @Override protected SoundEvent talkSound() { return ModSounds.SMUG_TALK.get(); }
    @Override protected SoundEvent getHurtSound(DamageSource src) { return ModSounds.SMUG_HURT.get(); }
    @Override protected SoundEvent getDeathSound() { return ModSounds.SMUG_DEATH.get(); }
}
