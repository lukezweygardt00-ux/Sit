package com.sitandwatch.client;

import com.mojang.blaze3d.systems.RenderSystem;
import com.sitandwatch.SitAndWatch;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraftforge.client.gui.overlay.ForgeGui;

/** Story objective/minimap, subtitle and cinematic overlay. */
public class HudOverlay {
    private static final ResourceLocation BLOOD = new ResourceLocation(SitAndWatch.MOD_ID, "textures/gui/blood.png");
    private static final int BLOOD_W = 1024, BLOOD_H = 702;

    public static void render(ForgeGui gui, GuiGraphics g, float partialTick, int w, int h) {
        Minecraft mc = Minecraft.getInstance();
        if (!ClientState.guideKey.isEmpty() && mc.player != null) {
            drawGuide(mc, g, w);
        }
        if (ClientState.bloodTicks > 0) {
            float f = Mth.clamp((ClientState.bloodTicks - partialTick) / (float) ClientState.bloodMax * 1.8f, 0f, 1f);
            RenderSystem.enableBlend();
            RenderSystem.defaultBlendFunc();
            g.setColor(1f, 1f, 1f, f * 0.92f);
            g.blit(BLOOD, 0, 0, w, h, 0, 0, BLOOD_W, BLOOD_H, BLOOD_W, BLOOD_H);
            g.setColor(1f, 1f, 1f, 1f);
            RenderSystem.disableBlend();
        }
        if (ClientState.subTicks > 0 && !ClientState.subKey.isEmpty()) {
            float f = Mth.clamp(Math.min(ClientState.subTicks, ClientState.subMax - ClientState.subTicks + 10) / 10f, 0f, 1f);
            int alpha = Mth.clamp((int) (255 * f), 8, 255);
            Component text = Component.translatable(ClientState.subKey);
            var pose = g.pose();
            pose.pushPose();
            pose.translate(w / 2f, h * 0.70f, 0);
            pose.scale(2.0f, 2.0f, 1.0f);
            if (ClientState.subDistorted) {
                float t = mc.player != null ? mc.player.tickCount : 0;
                float j = Mth.sin(t * 1.7f) * 1.5f;
                g.drawCenteredString(mc.font, text, (int) j, 0, (alpha / 2 << 24) | 0xFF2020);
                g.drawCenteredString(mc.font, text, (int) -j, 1, (alpha / 2 << 24) | 0x20E0FF);
            }
            g.drawCenteredString(mc.font, text, 0, 0, (alpha << 24) | 0xFFFFFF);
            pose.popPose();
        }

        float fade = ClientState.fadeAlpha();
        if (fade > 0.001f) {
            int alpha = Mth.clamp((int) (fade * 255.0f), 0, 255);
            g.fill(0, 0, w, h, alpha << 24);
        }
    }

    private static void drawGuide(Minecraft mc, GuiGraphics g, int screenWidth) {
        int mapPixels = ClientState.MAP_SIZE * 4;
        int mapX = screenWidth - mapPixels - 12;
        int mapY = 12;
        int panelX = 10, panelY = 12;
        int panelW = Math.max(128, Math.min(238, mapX - panelX - 18));

        g.fill(panelX, panelY, panelX + panelW, panelY + 48, 0xB80A0D16);
        g.fill(panelX, panelY, panelX + panelW, panelY + 2, 0xFFE0B65A);
        g.drawString(mc.font, Component.literal("CURRENT OBJECTIVE"), panelX + 8, panelY + 7, 0xFFFFD978, false);
        Component objective = Component.translatable(ClientState.guideKey);
        var lines = mc.font.split(objective, panelW - 16);
        int lineY = panelY + 21;
        for (int i = 0; i < Math.min(2, lines.size()); i++) {
            g.drawString(mc.font, lines.get(i), panelX + 8, lineY, 0xFFF4F1E8, false);
            lineY += 11;
        }

        if (!ClientState.mapReady) ClientState.refreshMinimap(mc);
        g.fill(mapX - 4, mapY - 4, mapX + mapPixels + 4, mapY + 8 + mapPixels + 17, 0xC00A0D16);
        g.fill(mapX - 4, mapY - 4, mapX + mapPixels + 4, mapY - 2, 0xFFE0B65A);
        g.drawString(mc.font, Component.literal("N"), mapX + mapPixels / 2 - 3, mapY - 1, 0xFFFFFFFF, true);
        for (int z = 0; z < ClientState.MAP_SIZE; z++) {
            for (int x = 0; x < ClientState.MAP_SIZE; x++) {
                int color = ClientState.mapPixels[z * ClientState.MAP_SIZE + x];
                int px = mapX + x * 4, py = mapY + z * 4 + 8;
                g.fill(px, py, px + 4, py + 4, color);
            }
        }
        int playerX = mapX + ClientState.MAP_RADIUS * 4 + 1;
        int playerY = mapY + 8 + ClientState.MAP_RADIUS * 4 + 1;
        g.fill(playerX - 2, playerY - 2, playerX + 3, playerY + 3, 0xFFFFFFFF);

        if (ClientState.guideHasTarget) {
            int dx = ClientState.guideX - ClientState.mapCenterX;
            int dz = ClientState.guideZ - ClientState.mapCenterZ;
            int mx = mapX + (ClientState.MAP_RADIUS + Math.max(-ClientState.MAP_RADIUS, Math.min(ClientState.MAP_RADIUS, dx))) * 4 + 2;
            int mz = mapY + 8 + (ClientState.MAP_RADIUS + Math.max(-ClientState.MAP_RADIUS, Math.min(ClientState.MAP_RADIUS, dz))) * 4 + 2;
            g.fill(mx - 2, mz - 2, mx + 3, mz + 3, 0xFFFFD34F);
            g.fill(mx - 1, mz - 1, mx + 2, mz + 2, 0xFF8E2C22);
        }
        int legendY = mapY + 8 + mapPixels + 5;
        g.fill(mapX + 5, legendY + 1, mapX + 10, legendY + 6, 0xFFFFFFFF);
        g.drawString(mc.font, Component.literal("YOU"), mapX + 13, legendY, 0xFFEDEDE8, false);
        if (ClientState.guideHasTarget) {
            g.fill(mapX + 49, legendY + 1, mapX + 54, legendY + 6, 0xFFFFD34F);
            g.drawString(mc.font, Component.literal("DESTINATION"), mapX + 57, legendY, 0xFFEDEDE8, false);
        }
    }
}
