package com.sitandwatch.client;

import com.sitandwatch.SitAndWatch;
import com.sitandwatch.entity.*;
import com.sitandwatch.registry.ModEntities;
import net.minecraft.client.renderer.entity.NoopRenderer;
import net.minecraft.server.packs.resources.ResourceManagerReloadListener;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.client.event.RegisterClientReloadListenersEvent;
import net.minecraftforge.client.event.RegisterGuiOverlaysEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = SitAndWatch.MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ClientSetup {
    @SubscribeEvent
    public static void registerRenderers(EntityRenderersEvent.RegisterRenderers e) {
        e.registerEntityRenderer(ModEntities.SMUG_BRO.get(), ctx -> new MeshRenderer<SmugBroEntity>(ctx, "smug_bro", "smug_bro", 0.5f));
        e.registerEntityRenderer(ModEntities.RON.get(), ctx -> new MeshRenderer<RonEntity>(ctx, "ron_villager", "ron_villager", 0.5f));
        e.registerEntityRenderer(ModEntities.SOCIAL_VILLAGER.get(), ctx -> new MeshRenderer<SocialVillagerEntity>(ctx, "social_villager", "social_villager", 0.5f));
        e.registerEntityRenderer(ModEntities.WATCHER.get(), ctx -> new MeshRenderer<WatcherEntity>(ctx, "the_watcher", "the_watcher", 0.0f));
        e.registerEntityRenderer(ModEntities.PERRY.get(), PerryRenderer::new);
        e.registerEntityRenderer(ModEntities.CHAIR_SEAT.get(), NoopRenderer::new);
    }

    @SubscribeEvent
    public static void registerReload(RegisterClientReloadListenersEvent e) {
        e.registerReloadListener((ResourceManagerReloadListener) rm -> MeshData.clear());
    }

    @SubscribeEvent
    public static void registerOverlays(RegisterGuiOverlaysEvent e) {
        e.registerAboveAll("story_overlay", HudOverlay::render);
    }
}
