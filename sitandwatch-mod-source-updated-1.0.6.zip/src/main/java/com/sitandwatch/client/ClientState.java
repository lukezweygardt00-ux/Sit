package com.sitandwatch.client;

import com.sitandwatch.network.EffectPacket;
import com.sitandwatch.registry.ModSounds;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.sounds.SoundSource;

/** Client-side story state mirrored from the server through packets. */
public class ClientState {
    public static boolean locked;
    public static float lockYaw, lockPitch;

    public static String subKey = "";
    public static int subTicks, subMax;
    public static boolean subDistorted;

    public static int bloodTicks, bloodMax;
    public static boolean ambience;

    // Story guide: 19x19 top-down map, sampled from the real block map colors.
    public static String guideKey = "";
    public static int guideX, guideZ;
    public static boolean guideHasTarget;
    public static final int MAP_SIZE = 19;
    public static final int MAP_RADIUS = MAP_SIZE / 2;
    public static final int[] mapPixels = new int[MAP_SIZE * MAP_SIZE];
    public static int mapCenterX, mapCenterZ;
    public static boolean mapReady;
    private static LoopingSound ambienceSound;

    // 0=clear, 1=fading to black, 2=holding black, 3=fading back in.
    private static int fadePhase, fadeTicks, fadeMax;

    public static void setLock(boolean l, float yaw, float pitch) {
        locked = l;
        lockYaw = yaw;
        lockPitch = pitch;
        Minecraft mc = Minecraft.getInstance();
        if (l && mc.player != null) {
            mc.player.setYRot(yaw);
            mc.player.setXRot(pitch);
            mc.player.yRotO = yaw;
            mc.player.xRotO = pitch;
        }
    }

    public static void setGuide(String key, int x, int z, boolean hasTarget) {
        guideKey = key == null ? "" : key;
        guideX = x;
        guideZ = z;
        guideHasTarget = hasTarget;
    }

    /** Refresh a north-up map using each surface block's vanilla map color. */
    public static void refreshMinimap(Minecraft mc) {
        if (mc.player == null || mc.level == null) { mapReady = false; return; }
        int cx = (int) Math.floor(mc.player.getX());
        int cz = (int) Math.floor(mc.player.getZ());
        if (mapReady && Math.abs(cx - mapCenterX) < 2 && Math.abs(cz - mapCenterZ) < 2) return;
        for (int dz = -MAP_RADIUS; dz <= MAP_RADIUS; dz++) {
            for (int dx = -MAP_RADIUS; dx <= MAP_RADIUS; dx++) {
                int x = cx + dx, z = cz + dz;
                int y = mc.level.getHeight(Heightmap.Types.WORLD_SURFACE, x, z) - 1;
                BlockPos pos = new BlockPos(x, Math.max(mc.level.getMinBuildHeight(), y), z);
                int rgb = mc.level.getBlockState(pos).getMapColor(mc.level, pos).col;
                if (rgb == 0) rgb = 0x26394A;
                mapPixels[(dz + MAP_RADIUS) * MAP_SIZE + (dx + MAP_RADIUS)] = 0xFF000000 | (rgb & 0xFFFFFF);
            }
        }
        mapCenterX = cx; mapCenterZ = cz; mapReady = true;
    }

    public static void showSubtitle(String key, int ticks, boolean distorted) {
        subKey = key;
        subTicks = subMax = ticks;
        subDistorted = distorted;
    }

    public static void nudge(float dYaw, float dPitch) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;
        mc.player.setYRot(mc.player.getYRot() + dYaw);
        mc.player.setXRot(mc.player.getXRot() + dPitch);
    }

    public static void effect(int type, int arg) {
        switch (type) {
            case EffectPacket.BLOOD -> { bloodTicks = bloodMax = Math.max(1, arg); }
            case EffectPacket.AMBIENCE_START -> {
                ambience = true;
                ambienceSound = new LoopingSound(ModSounds.AMBIENCE_LOOP.get(), SoundSource.AMBIENT, () -> ambience, () -> 0.9f);
                Minecraft.getInstance().getSoundManager().play(ambienceSound);
            }
            case EffectPacket.AMBIENCE_STOP -> ambience = false;
            case EffectPacket.FADE_OUT -> {
                fadeMax = fadeTicks = Math.max(1, arg);
                fadePhase = 1;
            }
            case EffectPacket.FADE_IN -> {
                fadeMax = fadeTicks = Math.max(1, arg);
                fadePhase = 3;
            }
            default -> { }
        }
    }

    public static void tick() {
        if (subTicks > 0) subTicks--;
        if (bloodTicks > 0) bloodTicks--;
        if (fadeTicks > 0) {
            fadeTicks--;
            if (fadeTicks == 0) {
                if (fadePhase == 1) fadePhase = 2;
                else if (fadePhase == 3) fadePhase = 0;
            }
        }
    }

    /** Alpha for the full-screen black transition, rendered above the normal HUD. */
    public static float fadeAlpha() {
        return switch (fadePhase) {
            case 1 -> 1.0f - fadeTicks / (float) Math.max(1, fadeMax);
            case 2 -> 1.0f;
            case 3 -> fadeTicks / (float) Math.max(1, fadeMax);
            default -> 0.0f;
        };
    }
}
