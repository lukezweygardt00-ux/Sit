package com.sitandwatch.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import com.sitandwatch.SitAndWatch;
import com.sitandwatch.entity.PerryEntity;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

/** Perry uses the uploaded Blockbench mesh and its matching embedded texture. */
public class PerryRenderer extends MobRenderer<PerryEntity, PerryMeshModel> {
    private static final ResourceLocation TEX =
            new ResourceLocation(SitAndWatch.MOD_ID, "textures/entity/perry_wolf.png");

    public PerryRenderer(EntityRendererProvider.Context ctx) {
        super(ctx, new PerryMeshModel(), 0.5f);
    }

    @Override
    protected void setupRotations(PerryEntity entity, PoseStack poseStack,
                                  float bob, float yBodyRot, float partialTick) {
        super.setupRotations(entity, poseStack, bob, yBodyRot, partialTick);
        // Keep Perry's occasional small twitch from the original character behavior.
        if (entity.tickCount % 37 < 3) {
            poseStack.mulPose(Axis.ZP.rotationDegrees(Mth.sin(entity.tickCount * 9.0f) * 1.8f));
        }
    }

    @Override
    public ResourceLocation getTextureLocation(PerryEntity entity) {
        return TEX;
    }
}
