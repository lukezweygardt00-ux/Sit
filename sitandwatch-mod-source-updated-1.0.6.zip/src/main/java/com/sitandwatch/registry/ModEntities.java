package com.sitandwatch.registry;

import com.sitandwatch.SitAndWatch;
import com.sitandwatch.entity.*;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, SitAndWatch.MOD_ID);

    public static final RegistryObject<EntityType<SmugBroEntity>> SMUG_BRO = ENTITIES.register("smug_bro", () ->
            EntityType.Builder.of(SmugBroEntity::new, MobCategory.CREATURE).sized(0.6f, 2.0f).clientTrackingRange(10).build("smug_bro"));
    public static final RegistryObject<EntityType<RonEntity>> RON = ENTITIES.register("ron_villager", () ->
            EntityType.Builder.of(RonEntity::new, MobCategory.CREATURE).sized(0.6f, 2.0f).clientTrackingRange(10).build("ron_villager"));
    public static final RegistryObject<EntityType<SocialVillagerEntity>> SOCIAL_VILLAGER = ENTITIES.register("social_villager", () ->
            EntityType.Builder.of(SocialVillagerEntity::new, MobCategory.CREATURE).sized(0.6f, 2.0f).clientTrackingRange(10).build("social_villager"));
    public static final RegistryObject<EntityType<PerryEntity>> PERRY = ENTITIES.register("perry_wolf", () ->
            EntityType.Builder.of(PerryEntity::new, MobCategory.CREATURE).sized(0.6f, 1.0f).clientTrackingRange(10).build("perry_wolf"));
    public static final RegistryObject<EntityType<WatcherEntity>> WATCHER = ENTITIES.register("the_watcher", () ->
            EntityType.Builder.of(WatcherEntity::new, MobCategory.MONSTER).sized(0.6f, 2.0f).clientTrackingRange(10).build("the_watcher"));
    public static final RegistryObject<EntityType<ChairSeatEntity>> CHAIR_SEAT = ENTITIES.register("chair_seat", () ->
            EntityType.Builder.<ChairSeatEntity>of(ChairSeatEntity::new, MobCategory.MISC).sized(0.1f, 0.1f).noSummon().fireImmune().clientTrackingRange(10).build("chair_seat"));
}
