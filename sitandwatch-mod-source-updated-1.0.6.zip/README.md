# Something Wants You To Sit And Watch (Forge 1.20.1)

Fan recreation for Minecraft Forge 1.20.1 (Forge 47.3.0, Java 17, official Mojang mappings).

## Build

The GitHub Actions workflow accepts a source ZIP uploaded directly to the repository root. The preferred filename is `sitandwatch-mod-source.zip`; it can also select a versioned `sitandwatch-mod-source*.zip` archive. The workflow builds the project and copies the result to the exact filename `Sit-and-watch.jar`, then publishes that file as a GitHub Actions artifact.

For a local build, use Gradle 8.1.1 with JDK 17: `gradle build --no-daemon`.

## Story flow

Day 1 begins at the gate of the village built around world spawn. Smug Bro approaches the player and gives a six-stop tour, waiting for the player at each stop rather than completing it automatically. The story clock pauses at the opening-tour stage so the first party night cannot be skipped; Perry does not spawn until the player completes the tour. Smug Bro's mansion appears layer-by-layer while the player looks away. During the party, Ron appears on open ground at a random village location, shivering until the player approaches within three blocks. On Day 3, if no zipper couch is already present in the player's home, the story places one and hides Ron inside it.

A compact objective panel and a north-up, map-colour minimap guide the player through the story; each objective changes when its task is completed. The village houses have exterior-only decoration and empty interiors. All house windows use full glass blocks to avoid the old pane rendering artifacts. Smug Bro's mansion has a more ornate exterior and a four-block 2×2 luxury mattress. Their doors are locked with the message `This is not your house. You cannot enter.` The player's own house remains accessible. Smug Bro's mansion is accessible, but entering its interior triggers his confrontation and escort-out sequence.

The basement trapdoor displays `This is locked.` before Night 4, triggers Smug Bro's confrontation/escort, and cannot be broken to bypass the lock. The Night 4 ending keeps the Watcher's spoken `Sit in the chair and watch` line but removes its on-screen subtitle/caption.

Story commands (operator): `/sitandwatch stage <1-8>`, `/sitandwatch release`, and `/sitandwatch reset`. A new world is the cleanest test. In an existing save, `/sitandwatch reset` resets the story data and rebuilds the village around world spawn, although already-spawned story entities or an older mansion outside the village footprint may remain.

## Current changes

- Adds a compact objective panel and minimap with player/destination markers, plus task prompts for the tour, mansion, Ron, couch, party, and basement stages.
- Builds Smug Bro's mansion one vertical layer at a time while the player looks away from the build site.
- Spawns Ron at a random open spot in the village; he lies shaking until the player approaches within three blocks, then follows as a friend.
- Replaces glass panes with full glass blocks on every generated house and the mansion to prevent pane rendering glitches.
- Removes the Watcher's sound-caption text while retaining his spoken line.
- Adds shooting-star particles and a subtle indigo night atmosphere, and improves the mansion facade/entry gardens and 2×2 luxury mattress.
- Names the downloadable JAR exactly `Sit-and-watch.jar`.
- Adds the supplied Ron scream recording and plays it immediately before the explosion.
- Makes Ron shake aggressively using a synchronized whole-model panic animation while he screams.
- Moves the explosion to the end of the full 13.235-second scream.
- Adds a stylized red particle burst around both Ron and the player, in addition to the screen splatter.
- Ends the basement scene with a 1.5-second fade to black, a teleport to the Overworld's shared world spawn (not the player's bed/respawn point), and a 1.5-second fade back in.
- Updates the source-ZIP workflow to extract the source from the repository root and upload the built JAR as `Sit-and-watch.jar`.

## v1.0.3 changes

- Replaced Ron's `gore_burst` explosion sound with the newly supplied OGG audio, keeping the existing sound event and playback code unchanged.

## v1.0.2 changes

- Retained the triangle-to-quad mesh batching fix that corrects the old JAR's smeared/glitched villager textures.
- Corrected the Day 1 tour so Smug Bro walks to the first stop instead of waiting at the plaza, waits for the player at every stop, and does not time out or skip the party sequence after sunset.
- Moved Perry's story spawn until after the tour is complete.
- Built the mansion for Night 1 and put Ron at the party so he is not missing from the first party night.
- Kept village house interiors empty and added locked-door messages, excluding the player's own home.
- Added the early basement lock message, Smug Bro escort behavior, and a break-event lock so the trapdoor cannot be mined around.
- Kept the Night 4 Watcher voice line playing even if the Watcher entity is not resolved at the voice cue.
- Reworked the mansion interior and basement decoration and rebuilt the staircase as a contiguous ascending run.
- Added automatic source-ZIP extraction to `.github/workflows/build.yml`.

## Assets still needed

Perry's supplied Blockbench model and embedded texture are included below. The reference video was used to guide the requested scene pacing and presentation; no separate torch-mod source/JAR was present to merge.

### Perry model source

Perry now renders from the supplied Blockbench source model at
`tools/source_models/jerry_normal.bbmodel`. Its embedded 1024x512 texture is
extracted to `src/main/resources/assets/sitandwatch/textures/entity/perry_wolf.png`,
and the model is packed into `src/main/resources/assets/sitandwatch/meshes/perry.bin`.

To regenerate those two runtime assets after editing the Blockbench model, install
Pillow and run `python tools/convert_perry.py` from the project root.

